# website-for-recovery-of-payment-delays
We did  this project of as part **SIH 2019**(Smart India Hackathon). we have given this solution to MSME(Ministry of Micro, Small & Medium Enterprises). We have used html,php and css for webiste building and sql to perform queries on the database.

*My Role:* My role in this project is Design and Test. I have designed the solution idea and done the tests wether the email is being sended correct or not.

**Description:**
* Samaadhaan is the online portal by Government of India to file complaints by industries regarding the delay or not recieving the payment from third party organizations.
* The problem statement given for us is to establish the better communication between the organizations regarding these complaints.
* The solution we given is to send recovery emails.whenever a complaint is registred in the portal mails regarding the status of case will be shared to that particular    organization such that they dont ignore the case.

